package mystore.ui;

import net.serenitybdd.screenplay.targets.Target;

public class MyAccountPage {
    public static final Target LOGIN_STATUS = Target.the("My login status")
            .locatedBy("//*[text()=\" Logged in as \"]");
}
