package mystore.ui;

import net.serenitybdd.screenplay.targets.Target;

public class LoginPage {
    public static final Target EMAIL = Target.the("email input")
            .locatedBy("input[data-qa=\"login-email\"]");
    public static final Target PASSWORD = Target.the("password input")
            .locatedBy("input[data-qa=\"login-password\"]");
    public static final Target LOGIN_BUTTON = Target.the("login button")
            .locatedBy("button[data-qa=\"login-button\"]");
}
