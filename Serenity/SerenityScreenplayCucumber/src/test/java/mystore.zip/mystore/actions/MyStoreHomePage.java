package mystore.actions;

import mystore.constanst.Constants;
import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.pages.PageObject;

@DefaultUrl(Constants.SIGN_IN_PAGE)
public class MyStoreHomePage extends PageObject {
}
