package mystore.constanst;

public class Constants {
    public static final String SIGN_IN_PAGE = "https://automationexercise.com/";
    public static final String LOGIN_STATUS_TITLE = "Logged in as Ivan Molero Delgado";
}
