package mystore.ui;


import net.serenitybdd.screenplay.targets.Target;

public class MainPage {
    public static final Target SECTION_PRODUCTS = Target.the("products section in main page")
            .locatedBy("a[href=\"/products\"]");
    public static final Target SECTION_LOGIN = Target.the("login section in main page")
            .locatedBy("a[href=\"/login\"]");
}
